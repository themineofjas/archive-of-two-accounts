# The Archive of Two Accounts

An original fictional investigative game you can host on any static website. No backend, database, Java, or framework required: JavaScript is included.

## Files
- `index.html` — page structure
- `style.css` — visual appearance and responsive layout
- `script.js` — six fictional documents, connections, and game behavior

## Play locally
Open `index.html` in a browser. Some browser/file viewers restrict localStorage; the game still works but may not retain progress.

## Publish with GitHub Pages
1. Create a public GitHub repository, e.g. `archive-of-two-accounts`.
2. Upload `index.html`, `style.css`, and `script.js` into the repository root (not inside a nested folder).
3. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, then `main` and `/ (root)`, and save.
4. Once published, share `https://YOUR-USERNAME.github.io/archive-of-two-accounts/`.
5. Alternatively, place the three files in a folder within an existing GitHub Pages website and navigate to that folder's URL.

## Customize the game
1. In `script.js`, edit the `documents` array. Each record has `id`, `type`, `title`, `author`, `summary`, `body`, and `question`.
2. Edit `connections` to define relationships between records. Use the IDs of the two records in `a` and `b`.
3. Change the game title, introduction, and ending choices in `index.html`. If changing the ending choices, update the `interpretations` object in `script.js` accordingly.
4. Change colors and fonts in `style.css`.
5. If you substantially revise the game and want old progress to reset, change `storageKey` in `script.js`.

## Privacy and limitations
Progress and draft notes are stored only in the player's browser via localStorage. Nothing is sent to you or a server. Players can download their own notes. No analytics, accounts, or backend. Search filters the six records by title, type, author, and body text. This prototype uses an evidence-based review rather than a strict score.

All story elements, places, characters, and records are invented.
